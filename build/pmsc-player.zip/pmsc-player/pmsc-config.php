<?
/*
 * Configuration settings for the PMSoundCloud Player
 */
// Name of the database table
define('PMSC_PLAYER_DB', $wpdb->prefix . 'pmsc_player');
?>